const http = require('http');
const scanner = require('sonarqube-scanner');
const port = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  const msg = 'Hello Node!\n'
  res.end(msg);
});

server.listen(port, () => {
  console.log(`Server running on http://localhost:${port}/`);
});


scanner(
  {
    serverUrl : 'http://54.167.226.27:9000/',
    token : "850b1ab1583182d7f44de181e3abd729b48e0288",
    options: {
      'sonar.projectName': 'My App',
      'sonar.projectKey': 'app',
      'sonar.projectDescription': 'Description for "My App" project...',
      //'sonar.sources': 'dist',
      //'sonar.tests': 'specs'
    }
  },
  () => process.exit()
)
